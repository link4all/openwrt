--- uci2dat.c	2015-12-31 19:03:28.000000000 +0800
+++ u2.c	2016-08-01 15:42:00.727294299 +0800
@@ -96,6 +96,13 @@
     param rekeyinteval;
     param preauth;
     param pmkcacheperiod;
+
+	/*apcli*/
+	param apcli_enable;
+	param apcli_ssid;
+	param apcli_authmode;
+	param apcli_encryptype;
+	param apcli_password;
 } vif;
 
 typedef struct
@@ -134,6 +141,13 @@
     .pmkcacheperiod     = {NULL, "pmkcacheperiod", {0}, NULL,  NULL},
     .preauth            = {NULL, "preauth", {0}, NULL,  NULL},
     .rekeyinteval       = {NULL, "rekeyinteval", {0}, NULL,  NULL},
+
+	/* ap-clinet */
+	.apcli_enable	    = {NULL, "ApCliEnable", {0}, NULL, NULL},
+	.apcli_ssid         = {NULL, "ApCliSsid", {0}, NULL, NULL},
+	.apcli_authmode     = {NULL, "ApCliAuthMode", {0}, NULL, NULL},
+	.apcli_encryptype   = {NULL, "ApCliEncrypType", {0}, NULL, NULL},
+	.apcli_password     = {NULL, "ApCliWPAPSK", {0}, NULL, NULL},
 };
 
 param CFG_ELEMENTS[] =
@@ -260,7 +274,6 @@
     {"HT_MpduDensity", NULL, {0}, hooker, "5"},
     {"HT_BW", "bw", {0}, hooker,  "0"},
     {"VHT_BW", "bw", {0}, hooker,  "0"},
-    {"VHT_Sec80_Channel", "vht2ndchannel", {0}, hooker, NULL},
     {"VHT_SGI", "vht_sgi", {0}, hooker,  "1"},
     {"VHT_STBC", "vht_stbc", {0}, hooker, "0"},
     {"VHT_BW_SIGNAL", "vht_bw_sig", {0}, hooker,  "0"},
@@ -282,14 +295,14 @@
     {"AutoProvisionEn", "autoprovision", {0}, hooker, "0"},
     {"FreqDelta", "freqdelta", {0}, hooker, "0"},
     {"CarrierDetect", "carrierdetect", {0}, hooker, "0"},
-//    {"ITxBfEn", "itxbf", {0}, hooker, "0"},
+    {"ITxBfEn", "itxbf", {0}, hooker, "0"},
     {"PreAntSwitch", "preantswitch", {0}, hooker, "1"},
     {"PhyRateLimit", "phyratelimit", {0}, hooker, "0"},
     {"DebugFlags", "debugflags", {0}, hooker, "0"},
-//    {"ETxBfEnCond", NULL, {0}, NULL, "0"},
+    {"ETxBfEnCond", NULL, {0}, NULL, "0"},
     {"ITxBfTimeout", NULL, {0}, NULL, "0"},
     {"ETxBfNoncompress", NULL, {0}, NULL, "0"},
-//    {"ETxBfIncapable", NULL, {0}, NULL, "1"},
+    {"ETxBfIncapable", NULL, {0}, NULL, "0"},
     {"FineAGC", "fineagc", {0}, hooker, "0"},
     {"StreamMode", "streammode", {0}, hooker, "0"},
     {"StreamModeMac0", NULL, {0}, NULL, NULL},
@@ -370,12 +383,12 @@
     {"idle_timeout_interval", "idle_intv", {0}, hooker, "0"},
     {"WiFiTest", NULL, {0}, NULL, "0"},
     {"TGnWifiTest", "tgnwifitest", {0}, hooker, "0"},
-    {"ApCliEnable", NULL, {0}, NULL, "0"},
-    {"ApCliSsid", NULL, {0}, NULL, NULL},
-    {"ApCliBssid", NULL, {0}, NULL, NULL},
-    {"ApCliAuthMode", NULL, {0}, NULL, NULL},
-    {"ApCliEncrypType", NULL, {0}, NULL, NULL},
-    {"ApCliWPAPSK", NULL, {0}, NULL, NULL},
+    {"ApCliEnable", "ApCliEnable", {0}, hooker, "0"},
+    {"ApCliSsid", "ApCliSsid", {0}, hooker, NULL},
+    {"ApCliBssid", "ApCliBssid", {0}, hooker, NULL},
+    {"ApCliAuthMode", "ApCliAuthMode", {0}, hooker, NULL},
+    {"ApCliEncrypType","ApCliEncrypType", {0}, hooker, NULL},
+    {"ApCliWPAPSK", "ApCliWPAPSK", {0}, hooker, NULL},
     {"ApCliDefaultKeyID", NULL, {0}, NULL, "0"},
     {"ApCliKey1Type", NULL, {0}, NULL, "0"},
     {"ApCliKey1Str", NULL, {0}, NULL, NULL},
@@ -386,7 +399,7 @@
     {"ApCliKey4Type", NULL, {0}, NULL, "0"},
     {"ApCliKey4Str", NULL, {0}, NULL, NULL},
     {"EfuseBufferMode", "efusebufmode", {0}, hooker, "0"},
-    {"E2pAccessMode", "e2paccmode", {0}, hooker, "1"},
+    {"E2pAccessMode", "e2paccmode", {0}, hooker, "2"},
     {"RadioOn", "radio", {0}, hooker, "1"},
     {"BW_Enable", "bw_enable", {0}, hooker, "0"},
     {"BW_Root", "bw_root", {0}, hooker, "0"},
@@ -402,16 +415,6 @@
     {"Wsc4digitPinCode", "wsc_4digitpin", {0}, hooker, NULL},
     {"WscVendorPinCode", "wsc_vendorpin", {0}, hooker, NULL},
     {"WscV2Support", "wsc_v2", {0}, hooker, NULL},
-    {"HT_MIMOPS", "mimops", {0}, hooker, "3"},
-    {"G_BAND_256QAM", "g256qam", {0}, hooker, "0"},
-    {"DBDC_MODE", "dbdc", {0}, hooker, "0"},
-    {"txbf", "txbf", {0}, hooker, "0"},
-    {"IgmpSnEnable", "igmpsnoop", {0}, hooker, "1"},
-
-    {"MUTxRxEnable", "mutxrxenable", {0}, hooker, "0"},
-
-    {"ITxBfEnCond", "itxbfencond", {0}, hooker, "0"},
-
 
 };
 
@@ -658,6 +661,12 @@
             PARSE_UCI_OPTION(wifi_cfg[cur_dev].vifs[cur_vif].rekeyinteval, value);
             PARSE_UCI_OPTION(wifi_cfg[cur_dev].vifs[cur_vif].preauth, value);
             PARSE_UCI_OPTION(wifi_cfg[cur_dev].vifs[cur_vif].pmkcacheperiod, value);
+			/*AP-CLIENT*/
+			PARSE_UCI_OPTION(wifi_cfg[cur_dev].vifs[cur_vif].apcli_enable, value);
+			PARSE_UCI_OPTION(wifi_cfg[cur_dev].vifs[cur_vif].apcli_ssid, value);
+			PARSE_UCI_OPTION(wifi_cfg[cur_dev].vifs[cur_vif].apcli_authmode, value);
+			PARSE_UCI_OPTION(wifi_cfg[cur_dev].vifs[cur_vif].apcli_encryptype, value);
+			PARSE_UCI_OPTION(wifi_cfg[cur_dev].vifs[cur_vif].apcli_password, value);
 #if 0
             PARSE_UCI_OPTION(wifi_cfg[cur_dev].vifs[cur_vif].authmode, value);
             PARSE_UCI_OPTION(wifi_cfg[cur_dev].vifs[cur_vif].cipher, value);
@@ -903,10 +912,6 @@
     {
         if(0 == strcmp(p->value, "2"))
             FPRINT(fp, p, "1");
-	else if (0 == strcmp(p->value, "3"))
-	    FPRINT(fp, p, "2");
-	else if (0 == strcmp(p->value, "4"))
-	    FPRINT(fp, p, "3");
         else
             FPRINT(fp, p, "0");
     }
@@ -1032,37 +1037,6 @@
         else
             FPRINT(fp, p, "%s", wifi_cfg[N].vifs[j].wepkey[i].value);
     }
-    else if (0 == strcmp(p->dat_key, "txbf"))
-    {
-       if (0 == strcmp(p->value, "3"))
-       {
-            FPRINT(fp, p, "3\n");
-            FPRINT(fp, p, "ETxBfEnCond=1\n");
-            FPRINT(fp, p, "ETxBfIncapable=0\n");
-            FPRINT(fp, p, "ITxBfEn=1");
-       }
-       else if (0 == strcmp(p->value, "2"))
-       {
-            FPRINT(fp, p, "2\n");
-            FPRINT(fp, p, "ETxBfEnCond=1\n");
-            FPRINT(fp, p, "ETxBfIncapable=0\n");
-            FPRINT(fp, p, "ITxBfEn=0");
-       }
-       else if (0 == strcmp(p->value, "1"))
-       {
-            FPRINT(fp, p, "1\n");
-            FPRINT(fp, p, "ETxBfEnCond=0\n");
-            FPRINT(fp, p, "ETxBfIncapable=1\n");
-            FPRINT(fp, p, "ITxBfEn=1");
-       }
-       else if (0 == strcmp(p->value, "0"))
-       {
-            FPRINT(fp, p, "0\n");
-            FPRINT(fp, p, "ETxBfEnCond=0\n");
-            FPRINT(fp, p, "ETxBfIncapable=1\n");
-            FPRINT(fp, p, "ITxBfEn=0");
-       }
-    }
 #if 0
     else if(0 == strmatch(p->dat_key, "ApCliKey?Type"))  /* Ap Client Mode */
     {
@@ -1085,6 +1059,26 @@
         /* TODO */
     }
 #endif
+	else if (0 == strmatch(p->dat_key, "ApCliEnable"))
+	{
+		FPRINT(fp, p, "%s", wifi_cfg[N].vifs[i].apcli_enable.value);
+	}
+	else if (0 == strmatch(p->dat_key, "ApCliSsid"))
+	{
+		FPRINT(fp, p, "%s", wifi_cfg[N].vifs[i].apcli_ssid.value);
+	}
+	else if (0 == strmatch(p->dat_key, "ApCliAuthMode"))
+	{
+		FPRINT(fp, p, "%s", wifi_cfg[N].vifs[i].apcli_authmode.value);
+	}
+	else if (0 == strmatch(p->dat_key, "ApCliEncrypType"))
+	{
+		FPRINT(fp, p, "%s", wifi_cfg[N].vifs[i].apcli_encryptype.value);
+	}
+	else if (0 == strmatch(p->dat_key, "ApCliWPAPSK"))
+	{
+		FPRINT(fp, p, "%s", wifi_cfg[N].vifs[i].apcli_password.value);
+	}
     /* the rest part is quite simple! */
     else
     {
@@ -1353,4 +1347,5 @@
 
 
 
+
 
